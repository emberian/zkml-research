#!/usr/bin/env python3
"""Persistent-host integration of the unchanged complete utility runner.

The shared staging routine and utility worker are reused byte-for-byte. A
Run subclass replaces only public host proposal calls with the existing
host_runtime stdio worker. Authority, verifier and issuer roles are unchanged.
"""
from __future__ import annotations
import argparse
import collections
import gzip
import hashlib
import json
from pathlib import Path
import select
import shutil
import subprocess
import sys
import tarfile
import time
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
UTILITY_SHA = 'ef69830929a4d262c155fd4dd228397edcb204e541957a63e89161ab8e3424b9'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def dump(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def worker(args):
    import utility_driver as utility
    assert sha((HERE / 'utility_driver.py').read_bytes()) == UTILITY_SHA
    sys.path.insert(0, str(HERE.parent / 'journal'))
    import run as run_module
    from common import canonical, require
    BaseRun = run_module.Run
    reports = Path(args.reports).resolve()

    class PersistentRun(BaseRun):
        def __init__(self, root, queries, binary):
            self.host_worker = None
            self.worker_events = []
            super().__init__(root, queries, binary=binary)
            self.worker_argv = [sys.executable, str(HERE.parent / 'host_runtime/host.py'), 'serve',
                                '--config', str(self.root / 'host_config.json'),
                                '--cas', str(self.host_cas.root)]
            self.worker_log = (self.root / 'host_worker.stderr').open('wb')
            self.worker_started = time.perf_counter_ns()
            self.host_worker = subprocess.Popen(self.worker_argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                                 stderr=self.worker_log)
            require(select.select([self.host_worker.stdout], [], [], 30)[0], 'hostWorkerStartupTimeout')
            ready = json.loads(self.host_worker.stdout.readline())
            require(ready == {'ok': True, 'ready': True}, 'hostWorkerReady')
            self.worker_startup_ns = time.perf_counter_ns() - self.worker_started
            self.worker_pid = self.host_worker.pid

        def role(self, command, **kwargs):
            if command != 'propose':
                return super().role(command, **kwargs)
            require(set(kwargs) == {'config', 'head', 'authorization', 'cas', 'out'}, 'hostProposalArguments')
            require(Path(kwargs['config']).resolve() == self.root / 'host_config.json', 'fixedPublicHostConfig')
            require(Path(kwargs['cas']).resolve() == self.host_cas.root.resolve(), 'fixedPublicHostCAS')
            message = {key: str(kwargs[key]) for key in ['head', 'authorization', 'out']}
            raw = canonical(message) + b'\n'
            start = time.perf_counter_ns()
            self.host_worker.stdin.write(raw)
            self.host_worker.stdin.flush()
            require(select.select([self.host_worker.stdout], [], [], 180)[0], 'hostWorkerProposalTimeout')
            response = self.host_worker.stdout.readline()
            elapsed = time.perf_counter_ns() - start
            reply = json.loads(response)
            require(reply.get('ok'), 'hostWorkerRejected:' + str(reply))
            stats = reply['request_stats']
            require(stats['cas_get_calls'] == stats['full_blob_sha256_calls'], 'everyHostGetRehashed')
            action = load(kwargs['authorization'])['payload']
            record = {'event_id': action['request_id'], 'kind': action['kind'],
                      'worker_pid': self.worker_pid, 'request_bytes': len(raw), 'response_bytes': len(response),
                      'caller_ns': elapsed, 'inside_propose_ns': reply['elapsed_ns'],
                      'request_stats': stats, 'cumulative_stats': reply['cumulative_stats'],
                      'inspection_cache_entries': reply['inspection_cache_entries'],
                      'proposal_result': reply['result']}
            self.worker_events.append(record)
            with (self.root / 'host_worker.jsonl').open('ab') as sink:
                sink.write(canonical(record) + b'\n')
            # Preserve the role-call evidence interface of the shared runner.
            call = {'role_process': 'propose', 'transport': 'persistent_stdio',
                    'worker_argv': self.worker_argv, 'message': message, 'elapsed_ns': elapsed,
                    'exit_code': 0, 'stdout': canonical(reply['result']).decode(), 'stderr': ''}
            self.calls.append(call)
            with (self.root / 'role_calls.jsonl').open('ab') as sink:
                sink.write(canonical(call) + b'\n')
            return reply['result']

        def close(self):
            if self.host_worker is not None:
                self.host_worker.stdin.close()
                require(self.host_worker.wait(timeout=30) == 0, 'hostWorkerCleanExit')
                lifetime = time.perf_counter_ns() - self.worker_started
                self.worker_log.close()
                root_report = reports / self.root.name
                rows = self.worker_events
                require(len(rows) == 240, 'oneWorkerCompleteHistory')
                counts = collections.Counter()
                for row in rows:
                    counts.update(row['request_stats']['crypto_calls'])
                actual = collections.Counter()
                cache = {}
                for line in (self.root / 'commands.jsonl').read_bytes().splitlines():
                    call = json.loads(line)
                    if call['role'] == 'host':
                        actual[call['command'][1]] += 1
                        if call['command'][1] == 'inspect':
                            meta = json.loads(call['stdout'])
                            cache[meta['sha256']] = meta
                require(actual == counts, 'hostMeterMatchesActualCryptoLog')
                final = rows[-1]['cumulative_stats']
                require(final['requests'] == 240 and final['crypto_calls'] == dict(counts), 'cumulativeHostCounts')
                require(len(cache) == rows[-1]['inspection_cache_entries'], 'cacheMetadataReconstruction')
                report = {'ok': True, 'worker_processes': 1, 'worker_pid': self.worker_pid,
                          'requests': len(rows), 'startup_ns': self.worker_startup_ns,
                          'lifetime_including_idle_pipeline_and_shutdown_ns': lifetime,
                          'proposal_caller_total_ns': sum(r['caller_ns'] for r in rows),
                          'proposal_inside_function_total_ns': sum(r['inside_propose_ns'] for r in rows),
                          'proposal_caller_plus_startup_ns': self.worker_startup_ns + sum(r['caller_ns'] for r in rows),
                          'stats': final, 'every_get_fully_rehashed': True,
                          'actual_crypto_log_matches_meter': True,
                          'inspection_cache_entries': len(cache),
                          'cache_canonical_json_bytes': len(canonical(cache)),
                          'stdio_request_bytes': sum(r['request_bytes'] for r in rows),
                          'stdio_response_bytes': sum(r['response_bytes'] for r in rows),
                          'worker_argv': self.worker_argv,
                          'cache_scope': 'Public inspection metadata grows with distinct ciphertexts; no eviction. Lifetime is one full history. JSON size is not heap/RSS.',
                          'trust_scope': 'Same SHA256/full reads, pinned binary checks, validators and public authority/verifier recomputation; no new credential or OS isolation.'}
                dump(root_report / 'host_worker_report.json', report)
                with gzip.open(root_report / 'host_worker.jsonl.gz', 'wb') as sink:
                    sink.write((self.root / 'host_worker.jsonl').read_bytes())
            super().close()

    run_module.Run = PersistentRun
    started = time.perf_counter_ns()
    utility.worker(args)
    full = load(reports / 'report.json')
    workers=[load(reports/f'history_{h}/host_worker_report.json') for h in [0,1]]
    summary={'ok':True,'schema':'semantic-complete-bfv-persistent-host-v1',
             'events':full['events'],'learns':full['learns'],'infers':full['infers'],
             'expiries':full['expiries'],'all_oracle_matches':full['all_oracle_matches'],
             'worker_processes':2,'workers':workers,'worker_elapsed_ns':time.perf_counter_ns()-started,
             'pipeline_elapsed_ns':full['elapsed_ns'],
             'scope':'One actual semantic consistency fixture. No cross-fixture speedup or new utility estimate; full BFV receiver key retained.'}
    dump(reports/'fast_report.json',summary)
    print(json.dumps({'ok':True,'events':full['events'],'verified_outputs':96,'fast_report':str(reports/'fast_report.json')}),flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--runtime', required=True)
    parser.add_argument('--reports', required=True)
    parser.add_argument('--binary', required=True)
    args=parser.parse_args()
    assert args.worker, 'Only the frozen normal worker entry point is staged'
    worker(args)
if __name__=='__main__':main()
